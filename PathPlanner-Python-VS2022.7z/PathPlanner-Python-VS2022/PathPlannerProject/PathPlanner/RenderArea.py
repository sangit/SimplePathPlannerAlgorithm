# Copyright (C) 2013 Riverbank Computing Limited.
# Copyright (C) 2022 The Qt Company Ltd.
# SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause
#
# Developed by: Md. Sayed  Aktar Rahman under LicenseRef-Qt-Commercial OR BSD-3-Clause

from PyQt5.QtCore import QPoint, Qt, QRect
from PyQt5.QtGui import QBrush, QPainter, QPalette, QPen
from PyQt5.QtWidgets import QApplication, QWidget
import sys

# the render area class
class RenderArea(QWidget):
    def __init__(self, parent=None, width=400, height=400):
        super().__init__(parent)
        
        self.resize(width, height)
        #self.setFixedSize(width, height)
        #self.setFixedHeight(self.height())  # For unresizeable height
        #self.setFixedWidth(self.width())    # For unresizeable width
        self.x_ini = int(self.width() / 2)
        self.y_ini = int(self.height() - 20)
        self.robot = QPoint(self.x_ini, self.y_ini)
        self.start = QPoint(self.x_ini, self.y_ini)
        self.end = QPoint(self.x_ini, 20)
        
        # variable for list of points as path
        self.path = []
        # variable for list of obstacles
        self.lstRect = []
        #self.path = [self.start,  self.end]
        #self.lstRect = [QRect(100, 150, 200, 50), QRect(30, 50, 200, 50)]

        # variable for length of robot
        self.rRobotLength = 8
        # variable for length of maximum reachable robot
        self.rReach = 5
        # variable for safe distance of robot to move
        self.rOffset = 10
                         
        self.setBackgroundRole(QPalette.Base)
        self.setAutoFillBackground(True)

    # function to set the robot, start, end, path, lstRect
    def set_objects(self, robot, start, end, path, lstRect):
        self.robot = robot
        self.start = start
        self.end = end
        self.path = path
        self.lstRect = lstRect
        self.update()

     # function to set the robot coordinates
    def set_robot_coordinates(self, robot):
        self.robot = robot
        self.update()

    # function to clear the robot coordinates
    def clear_robot_coordinates(self):
        self.robot.setX(self.x_ini)
        self.robot.setY(self.y_ini)
        self.update()

    # function to set the start coordinates
    def set_start_coordinates(self, start):
        self.start = start
        self.update()

    # function to clear the start coordinates
    def clear_start_coordinates(self):
        self.start.setX(self.x_ini)
        self.start.setY(self.y_ini)
        self.update()

    # function to set the end coordinates
    def set_end_coordinates(self, end):
        self.end = end
        self.update()

    # function to clear the end coordinates
    def clear_end_coordinates(self):
        self.end.setX(self.x_ini)
        self.end.setY(10)
        self.update()

    # function to set the path
    def set_path(self, path):
        self.path = path
        self.update()

    # function to clear the path
    def clear_path(self):
        self.path.clear()
        self.update()

    # function to add an obstacle
    def add_rect(self, rect):
        self.lstRect.append(rect)
        self.update()

    # function to clear obstacles
    def clear_rects(self):
        self.lstRect.clear()
        self.update()

    # function to get obstacles
    def return_lstRects(self):
        return self.lstRect

    # function to get start
    def return_start(self):
        return self.start

    # function to get end
    def return_end(self):
        return self.end

    # function to get robot
    def return_robot(self):
        return self.robot

    # function to get path
    def return_path(self):
        return self.path

    # function to set safe distance of robot to move
    def set_robot_offset(self, rOffset):
        self.rOffset = rOffset
        self.update()

    # function to get safe distance of robot to move
    def return_robot_offset(self):
        return self.rOffset

    # function to set maximum distance of robot to move
    def set_robot_reach(self, rReach):
        self.rReach = rReach
        self.update()

    # function to get maximum distance of robot to move
    def return_robot_reach(self):
        return self.rReach

    # paint event of render area
    def paintEvent(self, event):
       painter = QPainter(self)            
       
       #// drawing the robot ......            
       painter.setPen(self.palette().dark().color().red())
       painter.setBrush(QBrush(Qt.green, Qt.SolidPattern))
       x = int(self.robot.x() - self.rRobotLength / 2)
       y = int(self.robot.y() - self.rRobotLength / 2)
       painter.drawEllipse(x, y, self.rRobotLength, self.rRobotLength)
            
       # // Drawing the start point ..........            
       painter.setBrush(Qt.NoBrush)
       painter.setPen(self.palette().dark().color().blue())            
       painter.drawEllipse(self.start.x() - 5, self.start.y() -5, 10, 10)
                         
       # // Drawing the end point ..........            
       painter.setPen(self.palette().dark().color().blue())            
       painter.drawEllipse(self.end.x() - 5, self.end.y() - 5, 10, 10)
       
       # draw the path
       if len(self.path) > 0:
          painter.drawPolyline(self.path)
                       
       # draw the obstacles
       painter.setPen(self.palette().dark().color().black())       
       if len(self.lstRect) > 0:
           for rect in self.lstRect:
               painter.drawRect(rect)


# the main test function
if __name__ == '__main__':
    app = QApplication(sys.argv)
    widget = RenderArea()
    widget.setWindowTitle("Render Area Example")
    widget.resize(400, 400)
    widget.show()
    app.exec_()