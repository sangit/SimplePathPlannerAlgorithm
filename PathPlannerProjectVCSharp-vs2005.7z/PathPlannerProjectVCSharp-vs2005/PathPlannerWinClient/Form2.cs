using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PathPlannerWinClient
{
    public partial class Form2 : Form
    {
        public int topLeftX = 0;
        public int topLeftY = 0;
        public int bottomRightX = 0;
        public int bottomRightY = 0;

        public Form2()
        {
            InitializeComponent();
        }

        // Button click fuction for OK
        private void button1_Click(object sender, EventArgs e)
        {
            topLeftX = Convert.ToByte(tlX.Text);
            topLeftY = Convert.ToByte(tlY.Text);
            bottomRightX = Convert.ToByte(brX.Text);
            bottomRightY = Convert.ToByte(brY.Text);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        // Button click fuction for Cancel
        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}