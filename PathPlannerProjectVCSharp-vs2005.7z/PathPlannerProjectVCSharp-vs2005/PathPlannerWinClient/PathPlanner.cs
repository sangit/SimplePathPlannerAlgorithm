﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PathPlannerWinClient
{
    // pathplanner class
    class PathPlanner
    {
        // variable for list of points as path
        private List<System.Drawing.Point> lstPoints = new List<System.Drawing.Point>();
        // variable for safe distance of robot to move
        int rOffset;

        // class constructor
        public PathPlanner(int offset)
        {
            rOffset = offset;       
        }        
        
        // function is true if point is within rectangle else false
        public bool InRectangle(System.Drawing.Rectangle rect, System.Drawing.Point point)
        {
            return (point.X >= rect.Left) && (point.X <= rect.Right) && (point.Y >= rect.Top) && (point.Y <= rect.Bottom); 
        
        }

        // function is true if line of sight is there else false
        public bool LookAt(System.Drawing.Point start, System.Drawing.Point end, System.Drawing.Rectangle obstacle)
        {
            List<System.Drawing.Point> pts = new List<System.Drawing.Point>();

            //float NX = (int)Math.Abs(end.X - start.X);
            //float NY = (int)Math.Abs(end.Y - start.Y);

            float NX = (int)(end.X - start.X);
            float NY = (int)(end.Y - start.Y);            
            
            float N;
            if (NX > 0 && NY > 0) N = NX > NY ? NY : NX;  // smaller one is taken if both are greater than zero
            else N = (float)Math.Sqrt(NX * NX + NY * NY);

            NX = NX / N;
            NY = NY / N;

            for (int i = 0; i <= N; i++)
            {
                int x = (int)((float)start.X + i * NX);
                int y = (int)((float)start.Y + i * NY);
                pts.Add(new System.Drawing.Point(x, y));

            }
            
            foreach (System.Drawing.Point pt in pts)
            {
               if (InRectangle(obstacle, pt)) return false;
            }            

            return true;
        }

        // function returns the list of points as path
        List<System.Drawing.Point> RetPath()
        {
            return lstPoints;
        }

        // function calculates the path within obstacles
        public List<System.Drawing.Point> FindPath(List<System.Drawing.Rectangle> Rects, System.Drawing.Point start, System.Drawing.Point end)
        {

            //System.Drawing.Rectangle rect = Rects[0];
            lstPoints.Add(start);
            System.Drawing.Point pStart = start;                    
            
            foreach (System.Drawing.Rectangle rect in Rects)
            {
                if (LookAt(pStart, end, rect))
                {
                    System.Drawing.Point pt = start;
                    pt = NearestPoint(rect, pStart);
                    pt = NearToNearestPoint(rect, pt);
                    pStart.Y = pt.Y;
                    lstPoints.Add(pStart);
                }
                else
                {
                    pStart = NearestPoint(rect, pStart);
                    lstPoints.Add(pStart);
                    pStart = NearToNearestPoint(rect, pStart);
                    lstPoints.Add(pStart);
                }           
            }

            lstPoints.Add(end);
            
            return lstPoints;
        }

        // function returns the nearest point of the obstacle from a point
        public System.Drawing.Point NearestPoint(System.Drawing.Rectangle rect, System.Drawing.Point point)
        {
            System.Drawing.Point pt = new System.Drawing.Point();
            
            int x1 = rect.X;
            int y1 = rect.Y - rect.Height;

            int x2 = rect.X + rect.Width;
            int y2 = rect.Y - rect.Height;

            int x3 = rect.X + rect.Width;
            int y3 = rect.Y;

            int x4 = rect.X;
            int y4 = rect.Y;

            if(Math.Sqrt((x1-point.X)*(x1-point.X)+(y1-point.Y)*(y1-point.Y)) < Math.Sqrt((x2-point.X)*(x2-point.X)+(y2-point.Y)*(y2-point.Y))) 
            {
                pt.X = x1 - rOffset;
                pt.Y = y1 - rOffset;
            }
            else
            {
                pt.X = x2 + rOffset;
                pt.Y = y2 - rOffset;
            
            }

            return pt;
                 
        }

        // function returns the near to nearest point of the obstacle from a point
        public System.Drawing.Point NearToNearestPoint(System.Drawing.Rectangle rect, System.Drawing.Point point)
        {
            System.Drawing.Point pt = new System.Drawing.Point();

            int x1 = rect.X;
            int y1 = rect.Y - rect.Height;

            int x2 = rect.X + rect.Width;
            int y2 = rect.Y - rect.Height;

            int x3 = rect.X + rect.Width;
            int y3 = rect.Y;

            int x4 = rect.X;
            int y4 = rect.Y;

            if (x1 == (point.X + rOffset) && y1 == (point.Y + rOffset))
            {   
                pt.X = x4-rOffset;
                pt.Y = y4+rOffset;
            }
            else if (x2 == (point.X - rOffset) && y2 == (point.Y + rOffset))
            {   
                pt.X = x3+rOffset;
                pt.Y = y3+rOffset;
           
            }
           
            return pt;
        }
    }
}
