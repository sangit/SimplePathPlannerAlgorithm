#!/usr/bin/env python3

"""
Developed by : Md. Sayed Aktar Rahman

License : CC-BY

This is a class to find a path from start to destination points through obstacles

"""
import math
from xmlrpc.client import Boolean

# Class for point
class Point():
    # initialization
    def __init__(self, x, y):
        self.X = x
        self.Y = y

# Class for rectangle
class Rectangle():
    # initialization
    def __init__(self, X, Y, Width, Height):
        self.X = X
        self.Y = Y
        self.Left = X
        self.Top = Y
        self.Right = X + Width
        self.Bottom = Y - Height
        self.Width = Width
        self.Height = Height

# Class for Path Planning
class PathPlanner():
    # initialization
    def __init__(self, offset):
        # variable for safe distance of robot to move
        self.rOffset = offset
        # variable for list of points as path
        self.lstPoints = []


    # function is true if point is within rectangle else false
    def InRectangle(self, rect, point):
        if (point.X >= rect.Left) and (point.X <= rect.Right) and (point.Y <= rect.Top) and (point.Y >= rect.Bottom):
            return True
        else:
            return False

    # function is true if line of sight is there else false
    def LookAt(self, start, end, obstacle):
        pts = []

        NX = int(end.X - start.X)
        NY = int(end.Y - start.Y)
        N = 0

        if NX > 0 and NY > 0:
            # smaller one is taken if both are greater than zero
            if NX > NY:
                N = int(NY)
            else:
                N = int(NX)
        else:
            N = int(math.sqrt(NX * NX + NY * NY))

        NX = NX / N
        NY = NY / N

        for i in range(0, N+1):
            x = int(float(start.X + i * NX))
            y = int(float(start.Y + i * NY))
            pts.append(Point(x, y))

        check = False
        
        for pt in pts:
            if self.InRectangle(obstacle, pt):
                check = True
                break
        
        if check:
            return False
        else:
            return True

    # function returns the list of points as path
    def RetPath(self):
        return self.lstPoints

    # function calculates the path within obstacles
    def FindPath(self, Rects, start, end):
        self.lstPoints.append(start)
        pStart = Point(start.X, start.Y)

        for rect in Rects:
            if self.LookAt(pStart, end, rect):
                pt = self.NearestPoint(rect, pStart)
                pt = self.NearToNearestPoint(rect, pt)
                pt .X = pStart.X
                self.lstPoints.append(pt)
                pStart = pt
            else:
                pStart = self.NearestPoint(rect, pStart)
                self.lstPoints.append(pStart)
                pStart = self.NearToNearestPoint(rect, pStart)
                self.lstPoints.append(pStart)

        self.lstPoints.append(end)
        return self.lstPoints

    # function returns the nearest point of the obstacle from a point
    def NearestPoint(self, rect, point):
        pt = Point(0, 0)
        x1 = rect.X
        y1 = rect.Y - rect.Height

        x2 = rect.X + rect.Width
        y2 = rect.Y - rect.Height

        x3 = rect.X + rect.Width
        y3 = rect.Y

        x4 = rect.X
        y4 = rect.Y

        if math.sqrt((x1-point.X)*(x1-point.X)+(y1-point.Y)*(y1-point.Y)) < math.sqrt((x2-point.X)*(x2-point.X)+(y2-point.Y)*(y2-point.Y)):
            pt.X = x1 - self.rOffset
            pt.Y = y1 - self.rOffset
        else:
            pt.X = x2 + self.rOffset
            pt.Y = y2 - self.rOffset

        return pt

    # function returns the near to nearest point of the obstacle from a point
    def NearToNearestPoint(self, rect, point):
        pt = Point(0, 0)

        x1 = rect.X
        y1 = rect.Y - rect.Height

        x2 = rect.X + rect.Width
        y2 = rect.Y - rect.Height

        x3 = rect.X + rect.Width
        y3 = rect.Y

        x4 = rect.X
        y4 = rect.Y

        if x1 == (point.X + self.rOffset) and y1 == (point.Y + self.rOffset):
            pt.X = x4 - self.rOffset
            pt.Y = y4 + self.rOffset
        elif x2 == (point.X - self.rOffset) and y2 == (point.Y + self.rOffset):
            pt.X = x3 + self.rOffset
            pt.Y = y3 + self.rOffset

        return pt


# the main test function
if __name__ == '__main__':
    pt = Point(5, 7)
    rect = Rectangle(0, 0, 8, 9)
    print("The point is at x: " + str(pt.X) + " and y: " + str(pt.Y))
    print("The width of rectangle: " + str(rect.Width))
    print("The height of rectangle: " + str(rect.Height))

    robot = Point(0, 0)
    lstRect = []

    rRobotLength = 4
    rReach = 2.5
    rOffset = 2 * rReach

    del_X = 0
    prev_X = 0
    topLeftX = 0
    topLeftY = 0
    bottomRightX = 0
    bottomRightY = 0
    xOrig = 0
    yOrig = 0

    rect = Rectangle(10, 30, 40, 5)
    lstRect.append(rect)
    rect = Rectangle(45, 60, 40, 5)
    lstRect.append(rect)
    rect = Rectangle(10, 65, 40, 5)
    lstRect.append(rect)
    rect = Rectangle(45, 75, 30, 5)
    lstRect.append(rect)

    start = Point(50, 5)
    end = Point(50, 90)

    if len(lstRect) > 0:
        pPlannner = PathPlanner(rOffset)
        pPath = pPlannner.FindPath(lstRect, start, end)

        if len(pPath) > 0:
            for pt in pPath:
                print("Path - x: " + str(pt.X) + " y:" + str(pt.Y))







