using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PathPlannerWinClient
{
    public partial class Form1 : Form
    {
        // variable for list of obstacles
        List<System.Drawing.Rectangle> lstRect = new List<System.Drawing.Rectangle>();
        // variable for list of points as path
        List<System.Drawing.Point> path = new List<System.Drawing.Point>();
        // variable for list of points of walkiing path
        List<System.Drawing.Point> pathWalk = new List<System.Drawing.Point>();
        // variable for index of walkiing pathlist point
        int pathWalkIndex = 0;

        // variable for robot
        System.Drawing.Point robot;
        // variable for length of robot
        int rRobotLength = 4;
        // variable for length of maximum reachable robot
        int rReach = 5;
        // variable for safe distance of robot to move
        int rOffset = 10;

        public Form1()
        {
            InitializeComponent();

            // addition of four obstacles
            AddRect(10, 15, 50, 5);
            AddRect(40, 35, 50, 5);
            //AddRect(10, 55, 50, 5);
            AddRect(50, 55, 40, 5);
            //AddRect(40, 75, 50, 5);
            AddRect(20, 75, 50, 5);

            rOffset = 2 * rReach;

            robot = new System.Drawing.Point(pictureBox1.Width / 2, pictureBox1.Height - 20);
        }

        // paint event of picturebox
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            // drawing the robot ......
            e.Graphics.DrawEllipse(
                new Pen(Color.Gold, 5f),
                robot.X - rRobotLength / 2, robot.Y - rRobotLength / 2, rRobotLength, rRobotLength);
            
            // Drawing the end point ..........
            e.Graphics.DrawEllipse(
                new Pen(Color.Blue, 3f),
                pictureBox1.Width / 2 - 5, 5, 10, 10);

            // Drawing the start point .......
            e.Graphics.DrawEllipse(
                new Pen(Color.Blue, 3f),
                pictureBox1.Width / 2 - 5, pictureBox1.Height - 25, 10, 10);

            // Drawing the obstacles .......
            foreach (System.Drawing.Rectangle pRect in lstRect)
            {
                e.Graphics.DrawRectangle(new Pen(Color.Brown, 2f), pRect);
            }

            System.Drawing.Point[] pts = new System.Drawing.Point[path.Count];

            int i = 0;

            foreach (System.Drawing.Point pt in path)
            {
                pts[i++] = pt;

            }

            // Drawing the path .......
            if (pts.Length > 0) e.Graphics.DrawLines(new Pen(Color.DarkGreen, 2f), pts);
        }

        // Button click fuction to add obstcles
        private void button1_Click(object sender, EventArgs e)
        {
            path.Clear();
            pathWalk.Clear();
            Form2 pForm = new Form2();
            DialogResult ret = pForm.ShowDialog();
            int topLeftX = pForm.topLeftX;
            int topLeftY = pForm.topLeftY;
            int bottomRightX = pForm.bottomRightX;
            int bottomRightY = pForm.bottomRightY;
            System.Drawing.Rectangle pRect = new System.Drawing.Rectangle();
            pRect.Y = pictureBox1.Height - topLeftY * pictureBox1.Height / 100;
            pRect.X = topLeftX * pictureBox1.Width / 100;
            pRect.Height = (topLeftY - bottomRightY) * pictureBox1.Height / 100;
            pRect.Width = (bottomRightX - topLeftX) * pictureBox1.Width / 100;
            if (ret == DialogResult.OK) lstRect.Add(pRect);
            pictureBox1.Refresh();
        }

        // Fuction to add obsatcles coordinates in percentages of screen from bottom x, y
        private void AddRect(int x, int y, int width, int height)
        {
            int Y = pictureBox1.Height - y * pictureBox1.Height / 100;
            int X = x * pictureBox1.Width / 100;
            int Height = height * pictureBox1.Height / 100;
            int Width = width * pictureBox1.Width / 100;
            System.Drawing.Rectangle pRect = new System.Drawing.Rectangle(X, Y, Width, Height);
            lstRect.Add(pRect);
            pictureBox1.Refresh();
        }

        // Button click fuction to calculate path
        private void button2_Click(object sender, EventArgs e)
        {
            System.Drawing.Point end = new System.Drawing.Point(pictureBox1.Width / 2, pictureBox1.Height - 10);
            System.Drawing.Point start = new System.Drawing.Point(pictureBox1.Width / 2, 20);
            
            if (lstRect.Count > 0)
            {
                List<System.Drawing.Rectangle> rects = new List<System.Drawing.Rectangle>();

                foreach (System.Drawing.Rectangle rect in lstRect)
                {
                    int Y = pictureBox1.Height - rect.Y;
                    System.Drawing.Rectangle pRect = new System.Drawing.Rectangle(rect.X, Y, rect.Width, rect.Height);
                    rects.Add(pRect);
                }
                
                PathPlanner pPlannner = new PathPlanner(rOffset);
                List<System.Drawing.Point> pPath = pPlannner.FindPath(rects, start, end);

                path.Clear();

                if (pPath.Count > 0)
                {
                    foreach (System.Drawing.Point pt in pPath)
                    {
                        System.Drawing.Point point = pt;
                        point.Y = pictureBox1.Height - pt.Y;
                        path.Add(point);
                    }
                    pictureBox1.Refresh();
                }
            }
            else
            {
                path.Clear();
                System.Drawing.Point point = start;
                point.Y = pictureBox1.Height - point.Y;
                path.Add(point);
                point = end;
                point.Y = pictureBox1.Height - point.Y;
                path.Add(point);
                pictureBox1.Refresh();
            }
        }

        // Button click fuction to clear path and obstacles
        private void button3_Click(object sender, EventArgs e)
        {
            lstRect.Clear();
            path.Clear();
            pathWalk.Clear();
            robot = new System.Drawing.Point(pictureBox1.Width / 2, pictureBox1.Height - 20);
            pictureBox1.Refresh();
        }

        // Button click fuction for the robot to walk or stop
        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text == "Walk")
            {
                button4.Text = "Stop";
                if (pathWalk.Count > 0) 
                {
                    timer1.Start();
                }
                else
                {
                    pathWalk.Clear();
                    if (path.Count > 0)
                    {
                        for (int i = 0; i < path.Count - 1; i++)
                        {
                            pathWalk.Add(path[i]);

                            System.Drawing.Point pt1 = path[i];
                            System.Drawing.Point pt2 = path[i + 1];

                            float NX = (int)(pt2.X - pt1.X);
                            float NY = (int)(pt2.Y - pt1.Y);
                            int length = (int)Math.Sqrt(NX * NX + NY * NY);

                            int N = length / rReach;
                            NX = NX / N;
                            NY = NY / N;

                            for (int j = 1; j < N; j++) // pt1 and pt2 are avoided
                            {
                                int x = (int)((float)pt1.X + j * NX);
                                int y = (int)((float)pt1.Y + j * NY);
                                pathWalk.Add(new System.Drawing.Point(x, y));
                            }

                            pathWalk.Add(path[path.Count - 1]);
                            pathWalkIndex = 0;
                            timer1.Start();
                        }
                    }                
                }
            }
            else 
            {
                timer1.Stop();
                button4.Text = "Walk";                            
            }            
        }

        // timer event
        private void timer1_Tick(object sender, EventArgs e)
        {
            pathWalkIndex++;
            robot = pathWalk[pathWalkIndex];
            pictureBox1.Refresh();
            if (pathWalkIndex == pathWalk.Count - 1)
            {
                timer1.Stop();
                button4.Text = "Walk";
                pathWalkIndex = 0;
            }
        }
    }
}