import sys
from ui_obstacles_dialog import Ui_Dialog
from PyQt5 import QtWidgets

class ObstaclesDialog(QtWidgets.QDialog, Ui_Dialog):
    def __init__(self):
        super(ObstaclesDialog, self).__init__()
        self.topLeftX = 0
        self.topLeftY = 0
        self.bottomRightX = 0
        self.bottomRightY = 0
        
        # Set up the user interface from Designer.
        self.setupUi(self)
        self.setFixedHeight(self.height())  # For unresizeable height
        self.setFixedWidth(self.width())    # For unresizeable width

        # Make some local modifications.
        self.pushButton_1.clicked.connect(self.button1_Click)
        self.pushButton_2.clicked.connect(self.button2_Click)

        # Connect up the buttons.
    
    # Button click fuction for OK
    def button1_Click(self):
        self.topLeftX = int(self.tlX.text())
        self.topLeftY = int(self.tlY.text())
        self.bottomRightX = int(self.brX.text())
        self.bottomRightY = int(self.brY.text())
        self.accept()

    # Button click fuction for Cancel
    def button2_Click(self):
        self.reject()

    # function to add extra uis
    def setupUI(self):
        print("SETUP UI:")


# the main test function
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = ObstaclesDialog()
    window.setupUI()
    window.show()
    sys.exit(app.exec_())