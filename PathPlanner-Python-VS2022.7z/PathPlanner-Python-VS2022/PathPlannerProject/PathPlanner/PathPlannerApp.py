import sys
import math
from tkinter.tix import TEXT
from ui_main_dialog import Ui_Dialog
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtCore import QTimer, QRect, QPoint
from RenderArea import RenderArea
from obstacles_dialog import ObstaclesDialog
from PathPlanner import PathPlanner, Rectangle, Point

class MainDialog(QtWidgets.QDialog, Ui_Dialog):
    def __init__(self):
        super(MainDialog, self).__init__()
        # timer variable for walking speed
        self.m_Timer = QTimer()
        self.m_Timer.setInterval(100)

        # Set up the user interface from Designer.
        self.setupUi(self)
        self.renderArea = RenderArea(self.frame, 398, 325)
        self.renderArea.setGeometry(QtCore.QRect(10, 10, 398, 325))
        #self.setFixedSize(self.width(), self.height())
        #self.setFixedHeight(self.height())  # For unresizeable height
        #self.setFixedWidth(self.width())    # For unresizeable width

        # variable for list of points of path
        self.path = []
        # variable for list of points of walkiing path
        self.pathWalk = []
        # variable for index of walkiing pathlist point
        self.pathWalkIndex = 0

        # addition of four obstacles
        self.AddRect(10, 15, 50, 5)
        self.AddRect(40, 35, 50, 5)
        #self.AddRect(10, 55, 50, 5)
        self.AddRect(50, 55, 40, 5)
        #self.AddRect(40, 75, 50, 5)
        self.AddRect(20, 75, 50, 5)

        # Make some local modifications.
        
        # Connect up the buttons and timer with slots(events).
        self.pushButton_1.clicked.connect(self.button1_Click)
        self.pushButton_2.clicked.connect(self.button2_Click)
        self.pushButton_3.clicked.connect(self.button3_Click)
        self.pushButton_4.clicked.connect(self.button4_Click)
        self.m_Timer.timeout.connect(self.timerEvent)
    
    # Fuction to add obstacles coordinates in percentages of screen from bottom x, y
    def AddRect(self, x, y, width, height):
        Y = int(self.renderArea.height() - y * self.renderArea.height() / 100)
        X = int(x * self.renderArea.width() / 100)
        Height = int(height * self.renderArea.height() / 100)
        Width = int(width * self.renderArea.width() / 100)
        pRect = QRect(X, Y, Width, Height)

        self.renderArea.add_rect(pRect)

    # Button click fuction to add obstcles
    def button1_Click(self):
        self.renderArea.clear_path()
        self.renderArea.clear_robot_coordinates()
        self.path.clear()
        self.pathWalk.clear()
        pForm = ObstaclesDialog()
        pForm.exec()
        topLeftX = pForm.topLeftX
        topLeftY = pForm.topLeftY
        bottomRightX = pForm.bottomRightX
        bottomRightY = pForm.bottomRightY
        
        Y = int(self.renderArea.height() - topLeftY * self.renderArea.height() / 100)
        X = int(topLeftX * self.renderArea.width() / 100)
        Height = int((topLeftY - bottomRightY) * self.renderArea.height() / 100)
        Width = int((bottomRightX - topLeftX) * self.renderArea.width() / 100)
        pRect = QRect(X, Y, Width, Height)

        self.renderArea.add_rect(pRect)

    # Button click fuction to calculate path
    def button2_Click(self):
        #x = self.renderArea.return_start().x()
        #y = self.renderArea.return_start().y()
        #height = self.renderArea.height()
        start = Point(self.renderArea.return_start().x(), self.renderArea.height() - self.renderArea.return_start().y())
        end =   Point(self.renderArea.return_end().x(), self.renderArea.height() - self.renderArea.return_end().y())
        lstRect = self.renderArea.return_lstRects()

        if len(lstRect) > 0:
            rects = []
            for rect in lstRect:
                Y = self.renderArea.height() - rect.y()
                pRect = Rectangle(rect.x(), Y, rect.width(), rect.height())
                rects.append(pRect)

            pPlannner = PathPlanner(self.renderArea.return_robot_offset())
            pPath = pPlannner.FindPath(rects, start, end)

            self.path.clear()

            if len(pPath) > 0:
                for pt in pPath:
                    Y = self.renderArea.height() - pt.Y
                    point = QPoint(pt.X, Y)
                    self.path.append(point)            
        else:
            self.path.clear()
            Y = self.renderArea.height() - start.Y
            point = QPoint(start.X, Y)
            self.path.append(point)
            Y = self.renderArea.height() - end.Y
            point = QPoint(end.X, Y)           
            self.path.append(point)    
        self.renderArea.set_path(self.path)
    
    # Button click fuction to clear path and obstacles
    def button3_Click(self):
        self.renderArea.clear_rects()
        self.renderArea.clear_path()
        self.renderArea.clear_robot_coordinates()
        self.path.clear()
        self.pathWalk.clear()

    # Button click fuction for the robot to walk or stop
    def button4_Click(self):
        if self.pushButton_4.text() == "Walk":
            self.pushButton_4.setText("Stop")
            if len(self.pathWalk) > 0:
                self.m_Timer.start()
            else:
                self.pathWalk.clear()
                if len(self.path) > 0:
                    for i in range(0, len(self.path) - 1):
                        self.pathWalk.append(self.path[i])
                        pt1 = self.path[i]
                        pt2 = self.path[i + 1]

                        NX = int(pt2.x() - pt1.x())
                        NY = int(pt2.y() - pt1.y())
                        length = int(math.sqrt(NX * NX + NY * NY))
                                    
                        N = int(length / self.renderArea.return_robot_reach())
                        NX = NX / N
                        NY = NY / N
             
                        #// pt1 and pt2 are avoided
                        for j in range(1, N):
                            x = int(pt1.x() + j * NX)
                            y = int(pt1.y() + j * NY)
                            self.pathWalk.append(QPoint(x, y))
                    self.pathWalk.append(self.path[len(self.path) - 1])
                    self.pathWalkIndex = 0
                    self.m_Timer.start()   

        else:
           self.m_Timer.stop()
           self.pushButton_4.setText("Walk")

    # timer event
    def timerEvent(self):
         #print(str(self.pathWalkIndex))
         self.pathWalkIndex = self.pathWalkIndex + 1
         robot = self.pathWalk[self.pathWalkIndex]
         self.renderArea.set_robot_coordinates(robot)
         if self.pathWalkIndex == (len(self.pathWalk) - 1):
            self.m_Timer.stop()
            self.pushButton_4.setText("Walk")
            self.pathWalkIndex = 0

    # function to add extra uis
    def setupUI(self):
        print("SETUP UI:")


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainDialog()
    window.setupUI()
    window.show()
    sys.exit(app.exec_())
